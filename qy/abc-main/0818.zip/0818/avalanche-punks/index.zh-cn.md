---
title: "Avalanche Punks"
description: "Avalanche Punks 是 AVAX 上原创的朋克合集！"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "avalanche-punks.png"
tags: ["Collectibles","Avalanche Punks"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Avalanche"
website: "https://avalanchepunks.com/"
twitter: "https://twitter.com/avaxpunks"
discord: "https://discord.gg/vAscsaCTkK"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/avalanchepunks"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

![sindai](sindai.png)

<p><strong>Avalanche Punks</strong> 是生活在 AVAX 区块链上的 10,000 名朋克的独特集合！ AVAX 系列采用传统朋克属性以及专为 Avalanche 系列设计的独特属性（包括标志性的 Avalanche 橙色背景）制作而成。&nbsp;</p>
<p>Avalanche Punks NFT 系列是限量发行的，成为 Avalanche Punk 持有者后，您对自己的 NFT 拥有完全的所有权。 &nbsp;</p>

![fdisn](fdisn.png)