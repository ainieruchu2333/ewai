---
title: "AvtoCross"
description: "#1 克罗诺斯链上的稳定交换和流动性协议"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "avtocross.png"
tags: ["DeFi","AvtoCross"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Cronos"
website: "https://avtocross.finance/?utm_source=DappRadar&utm_medium=deeplink&utm_campaign=visit-website#/"
twitter: "https://twitter.com/avtoCROSS"
discord: ""
telegram: "https://t.me/CronosStableSwap"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: "https://cronos-stable-swap.gitbook.io/cronos-stable-swap/"
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
<p>CROSS 是 Cronos 链上的自动做市商 (“AMM”)，专为稳定币和其他挂钩资产的低滑点交易而设计。</p>

![nsaifnf](nsaifnf.png)



## 什么是交叉？

CROSS 是 Cronos 链上的自动化做市商（“AMM”），专为稳定币和其他挂钩资产的**低滑点交易而设计。**

第一个基本和核心流动性产品是标志性的稳定币交叉池，其中包含一篮子三个与美元挂钩的稳定币，包括 USDC、USDT、DAI。该协议打算在其他稳定币积累流动性深度（如 BUSD、UST、MIM 等）时建立额外的元池，以及与跨链协议合作的 BTC 和 ETH 等锚定蓝筹池。

此外，成为稳定币 AMM 只是第一步，CROSS 设想构建一个流动性即服务协议，稳定币质押者可以享受多元化风险调整后的高回报，单一代币质押者享受更高的收益，人人皆赢随着整个 Cronos 生态系统中实体项目的流动性深度提高。

CROSS**是非托管**的，这意味着 CROSS 开发人员无权访问您的代币

**特征**
↔️ 贸易
以尽可能低的滑点在 Cronos 链上的稳定币之间进行交换。
 **CROSS 怎么赚**
赚取 CROSS 治理代币作为在任何 CROSS 核心产品（例如稳定币交叉池）中提供稳定币流动性的奖励。
或者，CROSS 和合作伙伴 DEX Cronaswap 都对流动性提供者进行了丰厚的奖励，以帮助减轻无常损失。 您可以在 CROSS 平台或 Cronaswap 的农场中质押 CROSS-xUSD LP

![nifa](\nifa.png)