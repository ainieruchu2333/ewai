﻿---
title: "Axie Infinity"
description: "🏹 战斗 ✨ 收集 ⟠ 赚取 // Axie 为游戏玩家。"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "axie-infinity.png"
tags: ["NFT Games","Axie Infinity"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: ""
website: "https://axieinfinity.com/?utm_source=DappRadar&utm_medium=deeplink&utm_campaign=visit-website"
twitter: "https://twitter.com/AxieInfinity"
discord: "https://discord.com/invite/qT8vQjJ"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: "https://www.reddit.com/r/AxieInfinity/"
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
<p>Axie Infinity 是一个受 Pokemon 启发的数字宠物世界，玩家可以在各种游戏中使用他们称为 Axies 的可爱角色。 Axie Infinity Universe 通过“免费游戏赚钱”游戏玩法和玩家拥有的经济，突出了区块链技术的优势。</p>

![dasd](dasd.png)

斧头是凶猛的生物，喜欢战斗、建造和寻找宝藏！

建立一个集合并在不断扩大的游戏世界中使用它们！Axie Infinity 使用称为区块链的尖端技术来奖励玩家的参与。

![nfisdnf](nfisdnf.png)

## 玩和赚钱

Axie 是一种新型游戏，由其玩家部分拥有和运营。

通过玩来赚取AXS 代币，并用它们来决定游戏的未来！

**阿克西：战斗**

建立不可阻挡的 Axies 团队并征服你的敌人！
每个 Axie 都有基于其基因的独特优势和劣势。拥有数十亿种可能的基因组合，可能性真的是无限的！