---
title: "Axie Marketplace"
description: "游戏 Axie Infinity 的官方市场。"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "axie-marketplace.png"
tags: ["Marketplaces","Axie Marketplace"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: ""
website: "https://marketplace.axieinfinity.com/"
twitter: "https://twitter.com/AxieInfinity"
discord: "https://discord.gg/qT8vQjJ"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: "https://www.reddit.com/r/AxieInfinity/"
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false

---

![dfnmgi](dfnmgi.png)

<p>游戏 Axie Infinity 的官方市场。 在这里您可以轻松找到 Axies、Land 和其他游戏中使用的各种物品。&nbsp;</p>
<p>Axie Infinity 是一个数字宠物社区，专注于收集、训练、饲养和与名为 Axie 的幻想生物战斗。</p>
<p>每个 Axie 都有存储在以太坊区块链上的独特基因数据。 每个 Axie 可以拥有数百个可能的身体部位中的 6 个。 每个身体部位都有自己的战斗动作，所以创造独特的小战士的组合是无限的！</p>



![dsani](dsani.png)