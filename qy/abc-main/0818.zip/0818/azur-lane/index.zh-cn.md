---
title: "Azur Lane"
description: "Azur Lane 游戏的我的团队同人画。
Azur Lane NSFW V2 是基于 Polygon 区块链的 ERC-721 代币。"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "azur-lane.png"
tags: ["Collectibles","Azur Lane"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Polygon"
website: "https://ichigo-nft.eu/?utm_source=DappRadar&utm_medium=deeplink&utm_campaign=visit-website"
twitter: "https://twitter.com/Ichigohu_nft"
discord: "https://discord.gg/73HpaHtecf"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false

---

![ngdig](ngdig.png)

**Azur Lane 游戏的我的团队同人画。**

<p>指挥官，你准备好见女孩了吗？</p>
<p>这个系列是由一款名为 Azur Lane 的游戏制作的，由我的团队制作的独特图画组成，其中的角色以美丽和色情的形式呈现！</p>



![sanf](sanf.png)