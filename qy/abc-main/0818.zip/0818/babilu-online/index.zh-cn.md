---
title: "Babilu Online"
description: "多人虚拟房间构建器，用户可以在其中导入和显示他们现有的 NFT（跨链）"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "babilu-online.png"
tags: ["NFT Games","Babilu Online"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Harmony"
website: "https://babilu.online/?utm_source=DappRadar&utm_medium=deeplink&utm_campaign=visit-website"
twitter: "https://twitter.com/alpha_batem"
discord: "https://discord.gg/cgKGFQG4jM"
telegram: "https://t.me/alphabatem"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

![gsdg](\gsdg.png)

<p>MMO 虚拟房间构建器，用户可以在其中导入并显示他们房间内其他生态系统的现有 NFT，并与朋友一起享受。 Babilu 专注于提供一种通过使用战利品盒来赚取结构的游戏。 DARIC 我们内部的通缩游戏代币。&nbsp;</p>
<p>用户还可以通过智能合约在游戏中以 P2P 方式交易/赌博 NFT利用 VRF 机制获得可证明的公平结果。用户可以通过游戏内活动获得 NFT 1155 的战利品箱，然后将这些战利品箱打开或出售给其他人。&nbsp;</p>
<p>可以通过燃烧内部游戏代币 DARIC 来打开战利品箱，一旦通过智能合约打开，战利品箱就会包含一个随机 NFT 物品，这些物品来自用户可以在其房间内放置和使用的物品“集合”。额外的收藏和掉落将通过社区驱动的比赛和赞助活动。</p>
<p>该平台将利用 ICP 进行所有底层房间连接，以确保游戏的完全去中心化，同时提供可在我们的智能合约中使用的替代 VRF 提供商，例如 ChainLink。</p>

![gdfg](gdfg.png)