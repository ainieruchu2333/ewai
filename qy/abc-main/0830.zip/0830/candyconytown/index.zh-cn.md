---
title: "CANDYCONYTOWN"
description: "CANDYCONYTOWN 是在以太坊区块链上随机生成 的 5,021 个社区驱动的 NFT 集合。
我们的目标是在元宇宙中建造糖果镇
，在多元宇宙中建造更多。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "candyconytown.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/candyconytown"
twitter: "https://www.twitter.com/candyconytown"
discord: "https://discord.gg/vp7Vb4Uqzv"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/candyconytown"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/candyconytown

![unnamed (2)](unnamed (2).png)

很久很久以前，在一个遥远的星球上……有一个城镇，那里有生物。糖果城。这是一个位于温暖、自然区域的海滨小镇。我们可以听到某人的推文和欢快的歌曲。吃各种热腾腾的水果和蔬菜。它总是充满了愉快的谈话和和平、友好的气氛。每个人都经历了很多。每个过去都应该有很多艰难的时期。“但从现在开始，我们可以活得开心快乐。” MAAT 都相信这一点。他们每天都过得很辛苦，也很快乐。

![unnamed](unnamed.png)

**截止至8月30日**

5.0K**项目**

1.2K**拥有者**

3.3**总容积**

<0.01**底价**