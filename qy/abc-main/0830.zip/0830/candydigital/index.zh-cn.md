---
title: "Candy Digital"
description: "欢迎来到糖果！在 OpenSea 或 mlb.candy.com 上购买我们世界级的 NFT。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "candydigital.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/candydigital"
twitter: "https://www.twitter.com/CandyDigital"
discord: "https://discord.gg/6dVf3W8Z"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/candydigital"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/candydigital

![unnamed](unnamed.png)

Candy 是美国职业棒球大联盟的官方 NFT 生态系统，球迷和收藏家可以在其中购买、交易和分享官方授权的 NFT，以加深他们对这项运动的热爱。Candy 的使命是开发下一代体育和文化数字资产，提供真实的物品和体验，以加深球迷的参与并将人们与他们的激情联系起来。

![unnamed (1)](unnamed (1).png)

##### ▶ 什么是数字糖果？

Candy Digital 是一个 NFT（不可替代代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 Candy Digital 代币？

总共有 48,749 个 Candy Digital NFT。目前，11,023 名所有者的钱包中至少有一个 Candy Digital NTF。

##### ▶ 最昂贵的 Candy Digital 销售是什么？

售出的最昂贵的 Candy Digital NFT 是 Angel Stadium Steel Edition #16/514。它于 2022-08-02（28 天前）以 140.7 美元的价格售出。

##### ▶ 最近卖出了多少 Candy Digital？

过去 30 天内售出了 41 个 Candy Digital NFT。

##### ▶ Candy Digital 的价格是多少？

在过去 30 天里，Candy Digital NFT 最便宜的销售额低于 7 美元，最高销售额超过 133 美元。过去 30 天，Candy Digital NFT 的中位价格为 35 美元。