---
title: "Cangjie"
description: "仓颉是汉字的创造者。仓颉 NFT 是由太极、五行、易经等生成的汉字。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cangjie.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cangjie"
twitter: "https://www.twitter.com/CangjieNFT"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cangjie

![dwd](dwd.png)

仓颉是汉字的缔造者。
其创立的汉字系统记录了中华文明的繁衍生息。
Cangjie(for Loot) 是 Loot 元宇宙的第一个汉字基础设施。
——海内存知己，天涯若比邻。

![dadad](dadad.png)

**截止至8月30日**

123**项目**

62**拥有者**

0.20**总容积**

5**底价**