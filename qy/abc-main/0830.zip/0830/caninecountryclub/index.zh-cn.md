---
title: "Canine Country Club"
description: "犬类乡村俱乐部是以太坊区块链上 10,000 个经典犬类 NFT 的复杂集合。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "caninecountryclub.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/caninecountryclub"
twitter: "https://www.twitter.com/CanineCClub"
discord: "https://discord.gg/U9eTdNhzSu"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/caninecountryclub

![unnamed](unnamed.png)

这一年是 2051 年。

人类已经离开地球，城市街道上到处都是低贱的动物。

一个由优雅的狗组成的社会是高尚品味的最后堡垒。

欢迎来到犬类乡村俱乐部：一个贵族享受嬉戏和无忧无虑生活的乌托邦。

![unnamed (1)](unnamed (1).png)

##### ▶ 什么是犬类乡村俱乐部？

Canine Country Club 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 Canine Country Club 代币？

总共有 2,533 个 Canine Country Club NFT。目前，451 位车主的钱包中至少有一份 Canine Country Club NTF。

##### ▶ 最近卖出了多少 Canine Country Club？

过去 30 天内共售出 0 个 Canine Country Club NFT。