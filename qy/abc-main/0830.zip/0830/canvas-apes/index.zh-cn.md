---
title: "Canvas Apes"
description: "当美术遇到 NFT 形式时会发生什么？帆布猿！在 Polygon 网络上拥有 1000 只独特的猿猴"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "canvas-apes.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/canvas-apes"
twitter: "https://www.twitter.com/CanvasApes"
discord: "https://discord.gg/neZmeJPTw7"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/canvasapes"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/canvas-apes

![unnamed (2)](unnamed (2).png)

##### ▶ 什么是画布猿？

Canvas Apes 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。

##### ▶ 存在多少 Canvas Apes 代币？

总共有 1,000 个 Canvas Apes NFT。目前，364 位所有者的钱包中至少有一个 Canvas Apes NTF。

##### ▶ 最近卖出了多少 Canvas Apes？

过去 30 天内售出 0 个 Canvas Apes NFT。

![unnamed](unnamed.png)

**截止至8月30日**

1.0K**项目**

364**拥有者**

13.2**总容积**

<0.01**底价**