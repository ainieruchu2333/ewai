---
title: "Canvas Cats"
description: "在我无法摆脱猫的海市蜃楼的那一天，4444 只帆布猫被召唤给我，作为在不确定时期的灵感，通过与它们联系，你可能认为自己是一个幸运的人。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "canvas-cats.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/canvas-cats"
twitter: "https ://twitter.com/CanvasCats"
discord: "https ://discord.gg/4NkbzqZt4P"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/canvas-cats

![unnamed (1)](unnamed (1).png)

所有 Canvas Cats 所有者（截至 22 年 5 月 28 日）都在 Polygon Poodles 白名单上，1 个免费薄荷！ https://mint.poodles.space白名单薄荷是活的！

![unnamed](unnamed.png)

##### ▶ 什么是帆布猫？

Canvas Cats 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 Canvas Cats 代币？

总共有 4,443 个 Canvas Cats NFT。目前，1,313 位业主的钱包中至少有一个 Canvas Cats NTF。

##### ▶ Canvas Cats 最昂贵的促销活动是什么？

售出的最昂贵的 Canvas Cats NFT 是 #3028。它于 2022-06-10（3 个月前）以 15.5 美元的价格售出。

##### ▶ 最近卖出了多少 Canvas Cats？

过去 30 天内售出了 30 个 Canvas Cats NFT。

##### ▶ Canvas Cats 的价格是多少？

在过去 30 天里，最便宜的 Canvas Cats NFT 销售额低于 2 美元，最高销售额超过 14 美元。过去 30 天，Canvas Cats NFT 的中位价格为 4 美元。

