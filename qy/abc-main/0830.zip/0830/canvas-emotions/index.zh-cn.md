---
title: "Canvas Emotions"
description: "444 幅手工设计和计算机生成的原创油画作品，描绘了各种情绪和情绪。300 DPI 的 4K 高质量分辨率 - 准备打印。所有者保留所有知识产权。持有者解锁对发展中基于艺术的生态系统的独家访问权。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "canvas-emotions.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/canvas-emotions"
twitter: "https://www.twitter.com/CanvasEmotions"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/canvas-emotions

![unnamed (2)](unnamed (2).png)

##### ▶ 什么是画布情绪？

Canvas Emotions 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。

##### ▶ 存在多少 Canvas Emotions 代币？

总共有 444 个 Canvas Emotions NFT。目前，329 位所有者的钱包中至少有一个 Canvas Emotions NTF。

##### ▶ 最昂贵的 Canvas Emotions 销售是什么？

最昂贵的 Canvas Emotions NFT 是 Canvas Emotions #108。它于 2022-06-18（2 个月前）以 4.4 美元的价格售出。

##### ▶ 最近卖出了多少 Canvas Emotions？

过去 30 天内售出了 1 个 Canvas Emotions NFT。

![unnamed](unnamed.png)

**截止至8月30日**

444**项目**

329**拥有者**

1.9**总容积**

<0.01**底价**