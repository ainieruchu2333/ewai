---
title: "Canverse World"
description: "画布勾勒出你非凡的宇宙艺术和所有权的概念在数字世界中正在迅速变化。Canverse 是一个开放空间，供一起做出改变的人使用。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "canverseworld.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/canverseworld"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/canverse2021/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/canverseworld

![dada](dada.png)

##### ▶ 什么是宇宙世界？

Canverse World 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 存在多少 Canverse World 代币？

总共有 374 个 Canverse World NFT。目前，186 位车主的钱包中至少有一个 Canverse World NTF。

##### ▶ Canverse World 最近卖出了多少？

过去 30 天内售出 0 个 Canverse World NFT。

![dadads](dadads.png)

**截止至8月30日**

374**项目**

186**拥有者**

0.17**总容积**

0.1**底价**