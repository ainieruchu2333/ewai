---
title: "CAP - 6toj3grB6w"
description: "欢迎来到 OpenSea 上的 CAP - 6toj3grB6w 之家。发现这个系列中最好的项目。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cap-6toj3grb6w.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cap-6toj3grb6w"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cap-6toj3grb6w

![unnamed (1)](unnamed (1).png)

##### ▶ 什么是 CAP - 6toj3grB6w？

CAP - 6toj3grB6w 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少个 CAP - 6toj3grB6w 代币？

总共有 1,265 个 CAP - 6toj3grB6w NFT。目前 14 位所有者的钱包中至少有一个 CAP - 6toj3grB6w NTF。

##### ▶ 最近卖出了多少个CAP-6toj3grB6w？

过去 30 天内售出了 0 CAP - 6toj3grB6w NFT。

![unnamed](unnamed.png)

**截止至8月30日**

1.3K**项目**

14**拥有者**

1.1**总容积**

