---
title: "Capital Ones The Match 22"
description: "由 Autograph 制作的 Capital One 的 The Match '22 系列限量版纪念收藏品。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "capital-ones-the-match-22.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/capital-ones-the-match-22"
twitter: ""
discord: "https://discord.gg/autograph"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/autograph.io"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/capital-ones-the-match-22

![unnamed (2)](unnamed (2).png)

##### ▶ 什么是 Capital Ones The Match 22？

Capital Ones Match 22 是一个 NFT（不可替代代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 Capital Ones The Match 22 代币？

总共有 3,176 个 Capital Ones The Match 22 NFT。目前，3,161 位车主的钱包中至少有一个 Capital Ones The Match 22 NTF。

##### ▶ 什么是最昂贵的 Capital Ones The Match 22 销售？

最昂贵的 Capital Ones The Match 22 NFT 是 Capital One 的 The Match '22: The Cart #1618。它于 2022-06-07（3 个月前）以 17.2 美元的价格售出。

##### ▶ Capital Ones The Match 22 最近卖出了多少？

过去 30 天内售出了 7 个 Capital Ones The Match 22 NFT。

![dasda](dasda.png)

3.2K**项目**

3.2K**拥有者**

0.16**总容积**

<0.01**底价**

