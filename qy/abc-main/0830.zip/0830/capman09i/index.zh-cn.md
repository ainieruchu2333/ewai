---
title: "capman09i"
description: "卡普曼躲在他的帽子里，因为他在别人面前太害羞了！相反，一个用帽子表达所有情绪的理智的人！"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "capman09i.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/capman09i"
twitter: "https://twitter.com/september09i"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/capman09i

![sinanf](sinanf.png)

※ 当你达到10分时，你将获得一个capman亚克力框架！- 艺术品正常等级：1 分 - 艺术品稀有等级：2 分 - 作品独特等级：3 分 - 艺术品传奇等级：3 分 --------- - ------------------------------------------ - Capman 故事比赛的获胜者：2积分 - Capman 比赛获胜者：2 分

![unnamed](unnamed.png)

**截止至8月30日**

25**项目**

6**拥有者**

185**总项目**

30**底价**

