---
title: "Captain Capitalism"
description: "Captain Capitalism 是以太坊区块链上最可爱的生成 NFT！"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "captain-capitalism.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/captain-capitalism"
twitter: "https://www.twitter.com/thecaptainnft"
discord: ""
telegram: "https://t.me/captaincapitalism"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/captain-capitalism

![dada](dada.png)

✨Captain Capitalism 是以太坊区块链上最可爱的生成 NFT！他是最可爱的一组生成的 NFT，为你的钱包带来好运。看看他是一个优雅、强盗、醉酒、女性和电子人——他有一些传奇故事要讲。

🎩每一款都是 100% 个性化、创意制作，并拥有多种属性，例如体型、肤色和配饰。

🎨 关注我们的 Twitter 获取最新消息并加入我们的 Telegram 与社区聊天。

![dwads](dwads.png)

**截止至8月30日**

528**项目**

65**拥有者**

2.2**容积**