---
title: "Car-Sun Collection"
description: "祝福！这是 Car-Sun 的第一个系列。随着时间的推移，收藏家将获得与 Car-Sun 的音乐和艺术相关的各种特权。加入我们这美妙的旅程吧！您的支持是极大的赞赏。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "car-suncollection.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/car-suncollection"
twitter: "https://www.twitter.com/CarDashSun"
discord: "https://discord.gg/u7pZTg34WG"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/Carsun.eth"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/car-suncollection

![unnamed (2)](unnamed (2).png)

##### ▶ 什么是 Car-Sun 系列？

Car-Sun Collection 是一个 NFT (Non-fungible token) 集合。存储在区块链上的数字艺术品集合。

##### ▶ Car-Sun Collection 代币有多少？

总共有 3 个 Car-Sun Collection NFT。目前 7 位车主的钱包中至少有一个 Car-Sun Collection NTF。

##### ▶ Car-Sun Collection 最昂贵的销售是什么？

售出的最昂贵的 Car-Sun Collection NFT 是 Howl。它于 2022-06-19（2 个月前）以 11 美元的价格售出。

##### ▶ Car-Sun Collection 最近卖出了多少？

过去 30 天内售出了 4 个 Car-Sun Collection NFT。

![unnamed](unnamed.png)

**截止至8月30日**

3**项目**

7**拥有者**

0.04**总容积**

<0.01**底价**