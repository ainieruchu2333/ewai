---
title: "CarBits"
description: "CarBits 是在区块链上行驶的体素汽车的集合。其中只有 320 个将被铸造。每个独特的 CarBit 都是手工打造的，完美无缺，为新的驱动程序做好了准备。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "carbits.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/carbits"
twitter: "https://www.twitter.com/CarBits_"
discord: "https://discord.gg/CXbWXwX8Ga"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/CarBits_"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/carbits

![unnamed](unnamed.png)

每一位 CarBits 车主都将在我们的完整收藏结束时收到他们汽车的 3D 模型。车主将收到所有必要的文件，让他们的汽车在虚拟世界、AR 应用程序中使用并进行 3D 打印。

##### ▶ 什么是 CarBits？

CarBits 是一个 NFT（不可替代代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 CarBits 代币？

总共有 64 个 CarBits NFT。目前，34 位车主的钱包中至少有一个 CarBits NTF。

##### ▶ 最近售出了多少 CarBit？

过去 30 天内售出了 0 个 CarBits NFT。

![unnamed (1)](unnamed (1).png)

**截止至8月30日**

64**项目**

34**拥有者**

6.0**总容积**

0.07**底价**