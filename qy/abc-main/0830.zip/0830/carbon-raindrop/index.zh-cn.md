---
title: "Carbon RainDrop"
description: "Carbon RainDrops 是由@yungwknd 创作的 100 个独特的、链上的、生成的作品的特殊集合"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "carbon-raindrop.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/carbon-raindrop"
twitter: "https://www.twitter.com/yungwknd"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/carbon-raindrop

![unnamed (2)](unnamed (2).png)

每个液滴是 0.1 ETH，其中 0.05 ETH (50%) 将用于通过@offsetra 购买碳补偿

总的来说，这将转化为大约 2000 吨的碳补偿。

![unnamed](unnamed.png)

##### ▶ 什么是碳雨滴？

Carbon RainDrop 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 存在多少个 Carbon RainDrop 代币？

总共有 100 个 Carbon RainDrop NFT。目前，64 位车主的钱包中至少有一个 Carbon RainDrop NTF。

##### ▶ 最近卖出了多少碳雨滴？

过去 30 天内售出 0 个 Carbon RainDrop NFT。