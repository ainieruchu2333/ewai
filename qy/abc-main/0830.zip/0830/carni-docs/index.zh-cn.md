---
title: "The Docs"
description: "Carnival Plague 是 Polygon 区块链上托管的 10,000 个独特的瘟疫医生 NFT 的集合。每个数字收藏品都是 Carnies 俱乐部的代币。使用此代币，您将有权访问 Carnival Plague 独家活动、路线图更新、项目新闻以及未来的抽奖活动和社区赠品"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "carni-docs.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/carni-docs"
twitter: "https://www.twitter.com/PlagueCarnival"
discord: "https://www.instagram.com/carnivalplague_show"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/carni-docs



我们的主要活动！一旦我们到达路线图的终点，我们将举办一次千载难逢的体验。

前 100 个 Doc NFT* 已经被铸造出来，用于赠品和独家活动。其余的将在发布当天在 Polygon 区块链上进行铸造。

一百 (100) 份文档将从市场中扣留。这些将用于未来的活动、赠品、奖品、给帮助过我们的人和我们的创作者的礼物——创作者不会从前 100 名中拿走。

![unnamed (1)](unnamed (1).png)

##### ▶ 什么是文档？

Docs 是一个 NFT（Non-fungible token）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少个 Docs 代币？

总共有 100 个 The Docs NFT。目前 2 位所有者的钱包中至少有一个 The Docs NTF。

##### ▶ Docs 最近卖出了多少？

过去 30 天内售出 0 个 The Docs NFT。

![unnamed](unnamed.png)