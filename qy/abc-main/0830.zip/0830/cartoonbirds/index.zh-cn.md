---
title: "CartoonBirds"
description: "3k CC0 鸟从无到有"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cartoonbirds.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cartoonbirds"
twitter: "https://www.twitter.com/CopyBirds"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cartoonbirds

CartoonBirds，3k CC0 鸟从无到有

![unnamed (1)](\unnamed (1).png)

**截止至8月30日**

2.4K**项目**

1.3K**拥有者**

0.01**总容积**

0.03**底价**

![unnamed](unnamed.png)