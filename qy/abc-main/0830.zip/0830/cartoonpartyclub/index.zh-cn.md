---
title: "Cartoon Party Club"
description: "Cartoon Party Club 是一个包含 4,000 个独特 NFT 的集合，这些 NFT 存在于 Polygon 区块链上。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cartoonpartyclub.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cartoonpartyclub"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cartoonpartyclub

这些由 Kantyrust 绘制的卡通人物是一场盛大派对的嘉宾。他们都是不同的，都有不同的情绪。他们只是在等待被收养参加聚会。每部卡通都有自己的故事。

![unnamed (1)](unnamed (1).png)

##### ▶ 什么是卡通派对俱乐部？

Cartoon Party Club 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少卡通派对俱乐部代币？

总共有 200 个卡通派对俱乐部 NFT。目前 6 位所有者的钱包中至少有一个卡通派对俱乐部 NTF。

##### ▶ 最近卖了多少卡通派对俱乐部？

过去 30 天内共售出 0 个 Cartoon Party Club NFT。

![unnamed](unnamed.png)

**截止至8月30日**

200**项目**

6**拥有者**

0.01**总容积**

<0.01**底价**