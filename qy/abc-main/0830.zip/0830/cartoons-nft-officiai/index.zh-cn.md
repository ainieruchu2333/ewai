---
title: "Cartoons Nft OfficiaI"
description: "由 eur0、celly、york 和 cloudy 开发的社区驱动的 nft 项目"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cartoons-nft-officiai.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cartoons-nft-officiai"
twitter: "https://www.twitter.com/cartoonsnft"
discord: "https://discord.gg/cartoons"
telegram: "https://t.me/cartoonsproject"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/cartoonsnft"
reddit: ""
medium: "https://www.medium.com/@cartoonsnft"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cartoons-nft-officiai

时光飞逝，每个人都错过了周六早上的卡通片。我们坚信我们所有人的孩子仍然存在并且我们都有权以我们认为合适的方式表达自己。NFT 的世界如此受欢迎，因为我们都怀念童年时怀念的东西。

让我们保持头脑清醒，继续梦想。

![dsad](dsad.png)

## 你有路线图吗？

我们的路线图包括薄荷/阿尔法通行证、irl 激活、为我们的持有人商业理念设立的赠款基金、项目启动板、卡通电视节目等等。我们坚信多做少说。话虽如此，我们有很多很棒的计划和想法，我们将朝着为我们的持有者增加更多技术、价值和实用性的方向前进。请继续关注即将公布的更多细节。

我们的完整路线图可以通过#roadmap 在我们的不和谐中查看

## 漫画什么时候上映？

卡通卡通清单铸造过程将于 2022 年 3 月 1 日太平洋标准时间下午 3 点/美国东部标准时间下午 6 点开始，并将连续运行 24 小时。保持活跃并确保您在我们的官方 Twitter 上启用了我们的通知，以确保您不会错过任何一个节拍

## 薄荷的数量和价格？

从卡通世界中铸造一个角色的价格将是 0.07 ETH，有 7,777 个独特的机会。

## 我可以铸造多少个 Nft？

每个 toony 最多可以铸造 2 个独特的卡通人物

![sdanin](sdanin.png)