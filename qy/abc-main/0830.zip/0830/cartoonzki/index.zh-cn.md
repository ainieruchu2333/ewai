---
title: "CartoonzKi"
description: "只退事！"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cartoonzki.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cartoonzki"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cartoonzki

![unnamed (1)](unnamed (1).png)

##### ▶ 什么是 CartoonzKi？

CartoonzKi 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 CartoonzKi 代币？

总共有 7,079 个 CartoonzKi NFT。目前，739 位所有者的钱包中至少有一个 CartoonzKi NTF。

##### ▶ 最近卖了多少 CartoonzKi？

过去 30 天内共售出 0 个 CartoonzKi NFT。

![unnamed](unnamed.png)

**截止至8月30日**

7.1K**项目**

739**拥有者**

0.05**总容积**

0.01**底价**