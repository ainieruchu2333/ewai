---
title: "CartridgePunkz"
description: "铸造 4 MATIC在你扫地之前，考虑为自己铸造一个闪亮的新墨盒朋克！"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cartridgepunkz.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cartridgepunkz"
twitter: "https://www.twitter.com/CartridgePunkz"
discord: "https://discord.gg/zxndYP2r2m"
telegram: "https://t.me/cartridgepunkz"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/cartridgepunkz"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cartridgepunkz



一系列独特的朋克肖像，灵感来自对复古电子游戏的怀旧。

Cartridge Punkz 曾经是人类，他们不小心被转移到了弹药筒中。他们将需要在受电脑游戏启发的世界中进步，以升级和拯救人类！

第一套 9999 Punkz 是通过我们网站上的铸币厂随机生成的，具有一系列属性和稀有度 - https://www.cartridgepunkz.com

所有销售收入的 10% 将捐赠给 Extra-Life，这是儿童奇迹网络医院慈善机构的一个部门，通过游戏世界筹集资金。

特许权使用费为 2.5%，将被放回项目中。

我们将以 999 个为一组。

![unnamed](unnamed.png)

##### ▶ 什么是 CartridgePunkz？

CartridgePunkz 是一个 NFT（不可替代令牌）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 CartridgePunkz 代币？

总共有 712 个 CartridgePunkz NFT。目前，231 位所有者的钱包中至少有一个 CartridgePunkz NTF。

##### ▶ 最近卖出了多少 CartridgePunkz？

过去 30 天内售出了 2 个 CartridgePunkz NFT。



![unnamed (2)](unnamed (2).png)