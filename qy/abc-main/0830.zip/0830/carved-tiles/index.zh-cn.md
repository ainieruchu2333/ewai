---
title: "Carved Tiles"
description: "艺术与科技的美丽碰撞。Carved Tiles 是 100 件单独的 Wood+Resin 艺术作品的集合。每个实体部件都镶嵌在坚固的金属框架中，并通过二维码连接到它的数字孪生体。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "carved-tiles.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/carved-tiles"
twitter: "https://www.twitter.com/carvednfts"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/carved"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/carved-tiles

![unnamed](unnamed.png)

##### ▶ 什么是雕刻瓷砖？

Carved Tiles 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少雕刻瓷砖代币？

总共有 100 个 Carved Tiles NFT。目前，59 位业主的钱包中至少有一个 Carved Tiles NTF。

##### ▶ 最近卖出了多少块雕刻瓷砖？

过去 30 天内售出了 0 个 Carved Tiles NFT。

![unnamedasd](unnamedasd.png)

**截止至8月30日**

100**项目**

59**拥有者**

14.0**总容积**

0.3**底价**