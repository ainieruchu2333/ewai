---
title: "Cases By Kate : IMAGINE"
description: "Kate 是一个收集 10,000 条与谋杀嫌疑人有关的线索的项目。它的设计是。收集香烟的成分，看看那个因想知道你是谁而快要发疯的人的脸。"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cases-by-kate-imagine.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cases-by-kate-imagine"
twitter: "https://twitter.com/CasesByKateNFT"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cases-by-kate-imagine

![unnamed (2)](unnamed (2).png)

文本推理 NFT，逐个凯特
Case by Kate 是一个由项目经理、开发人员和作家组成的 Klaytn 文本生成项目。于2021年9月开工，取得了韩国首个以故事为基础的文本格式项目的启动成果。

![unnamed](unnamed.png)

V1处理“警方追捕的凶手和凶手熟人的陈述”，而在V2中，持有者直接成为“菜鸟侦探”，在资深侦探沃森的帮助下调查罪犯，并获得一张插图卡，里面有犯罪。它处理过量用药。


文本项目，侦探/悬疑类型，所有这些似乎都很难获得。由于项目启动以来，有很多人要求使用或指南，团队意识到需要指南，并根据目前的数据完成了指南制作。