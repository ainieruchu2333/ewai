---
title: "Cassio Motta Club Polygon"
description: "多边形卡西欧莫塔俱乐部"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "cassio-motta-club-polygon.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/cassio-motta-club-polygon"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/cassio-motta-club-polygon

![das](das.png)

##### ▶ 什么是 Cassio Motta Club Polygon？

Cassio Motta Club Polygon 是一个 NFT（非同质代币）集合。存储在区块链上的数字艺术品集合。

##### ▶ 有多少 Cassio Motta Club Polygon 代币？

总共有 537 个 Cassio Motta Club Polygon NFT。目前，14 位车主的钱包中至少有一个 Cassio Motta Club Polygon NTF。

##### ▶ 最近售出了多少 Cassio Motta Club Polygon？

过去 30 天内售出了 0 个 Cassio Motta Club Polygon NFT。

![dasdi](dasdi.png)

**截止至8月30日**

537**项目**

14**拥有者**

0.01**总容积**

<0.01**底价**