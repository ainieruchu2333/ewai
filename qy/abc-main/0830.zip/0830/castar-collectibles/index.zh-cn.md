---
title: "Castar Collectibles"
description: "卡斯塔收藏品"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "castar-collectibles.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/castar-collectibles"
twitter: "https://www.twitter.com/https://twitter.com/CastarCollecti1"
discord: "https://discord.gg/Xy7UYhQp"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/castar-collectibles

![dasd](dasd.png)

Castar Collectibles 是 NFT 领域中的一种，它结合了一个独特的故事情节，随着每个新角色的掉落而进展。加入冒险并选择一个派系，看看谁将战胜卡斯塔。价格将于 3 月 30 日公布，请访问https://www.castarcollectibles.com/开始您的冒险并了解更多信息！

![wqeq](wqeq.png)

**截止至8月30日**

17**项目**

10**拥有者**

1.2**总容积**

