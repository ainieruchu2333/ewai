---
title: "Castle Kid's Eggdrop"
description: "Colin Tilley 的 Castle Kid 是一个生成艺术 NFT 项目，由 10,000 个具有不同特征的 Castle Kid 手绘组合以及稀有的 1/1 组成"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "castle-kids-eggdrop.png"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/castle-kids-eggdrop"
twitter: "https://www.twitter.com/CastleKidNFT"
discord: "https://discord.gg/castle"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/castlekidnft"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/castle-kids-eggdrop

![fisndi.ng](fisndi.ng.jpg)

##### ▶ 什么是 Castle Kid 的 Eggdrop？

Castle Kid's Eggdrop 是一个 NFT（非同质代币）系列。存储在区块链上的数字艺术品集合。

##### ▶ Castle Kid 的 Eggdrop 代币有多少？

总共有 2 个 Castle Kid 的 Eggdrop NFT。目前，4,876 位所有者的钱包中至少有一个 Castle Kid's Eggdrop NTF。

##### ▶ Castle Kid's Eggdrop 最昂贵的促销活动是什么？

最贵的 Castle Kid 的 Eggdrop NFT 是 Golden Egg。它于 2022 年 6 月 21 日（2 个月前）以 10.8 美元的价格售出。

##### ▶ Castle Kid's Eggdrop 最近卖出了多少？

过去 30 天内售出了 2 个 Castle Kid's Eggdrop NFT。

![unnamed](unnamed.png)

**截止至8月30日**

10.0K**项目**

4.5K**拥有者**

970**总容积**

<0.01**底价**