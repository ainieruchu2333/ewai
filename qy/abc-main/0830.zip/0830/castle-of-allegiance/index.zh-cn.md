---
title: "Castle Of Allegiance"
description: "1 ₣ⱤɆɆ / ₩₳ⱠⱠɆ₮, ₮ⱧɆ ⱤɆ₴₮ ₳₮ 0.004 20 / ₮Ӿ8,000 ⱧɄ₥₳₦, 1,000 ɆⱠVɆ₴ ₳₦Đ 1,000 ุⱤ₵₴Đ₳Ɽ₭ ₣ุⱤ₵Ɇ₴ ₳ⱤɆ ₵ุ₥ł₦₲。₱Ɽุ₮Ɇ₵₮ ₮ⱧɆ ₵₳₴₮ⱠɆ ₳₮ ₳ⱠⱠ ₵ุ₴₮₴。₦ุ ₩Ɇ฿₴ł₮Ɇ ₦ุ Đł₴₵ุⱤĐ ₵₵0"
date: 2022-08-30T00:00:00+08:00
lastmod: 2022-08-30T00:00:00+08:00
draft: false
authors: ["crazyxuanshao"]
featuredImage: "castle-of-allegiance.gif"
tags: ["Collectibles"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: ""
website: "https://opensea.io/collection/castle-of-allegiance"
twitter: "https://www.twitter.com/coa_eth"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
项目网站、社交联系方式、项目介绍内容详见：https://opensea.io/collection/castle-of-allegiance

![unnamed (2)](unnamed (2).png)

##### ▶ 什么是忠诚城堡？

Castle Of Allegiance 是一个 NFT（不可替代代币）系列。存储在区块链上的数字艺术品集合。

##### ▶ 忠诚城堡代币有多少？

总共有 9,830 个忠诚城堡 NFT。目前，2,855 位车主的钱包中至少有一个 Castle Of Allegiance NTF。

##### ▶ 最昂贵的忠诚城堡拍卖会是什么？

售出的最昂贵的 Castle Of Allegiance NFT 是 Knight #639。它于 2022-06-08（3 个月前）以 73 美元的价格售出。

##### ▶ 最近卖出了多少个忠心之城？

过去 30 天内售出了 103 个 Castle Of Allegiance NFT。

##### ▶ 效忠城堡的价格是多少？

过去 30 天，最便宜的 Castle Of Allegiance NFT 销售额低于 2 美元，最高销售额超过 16 美元。过去 30 天，Castle Of Allegiance NFT 的中位价格为 5 美元。

![unnamed](unnamed.png)

**截止至8月30日**

9.8K**项目**

2.9K**拥有者**

0.63**总容积**

<0.01**底价**